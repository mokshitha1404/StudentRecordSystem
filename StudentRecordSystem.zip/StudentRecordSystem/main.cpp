
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <cctype>

struct Student {
    int id;
    std::string name;
    int age;
    char grade;
};

int main() {
    auto start = std::chrono::high_resolution_clock::now();

    std::ifstream file("students.csv");
    if (!file) {
        std::cout << "students.csv not found\n";
        return 1;
    }

    std::vector<Student> students;
    std::string line;

    while (getline(file, line)) {
        if (line.empty()) continue;

        std::stringstream ss(line);
        Student s;
        std::string temp;

        // ID
        if (!getline(ss, temp, ',')) continue;
        if (temp.empty() || !isdigit(temp[0])) continue;
        s.id = stoi(temp);

        // Name
        if (!getline(ss, s.name, ',')) continue;

        // Age
        if (!getline(ss, temp, ',')) continue;
        s.age = stoi(temp);

        // Grade
        if (!getline(ss, temp, ',')) continue;
        s.grade = temp[0];

        students.push_back(s);
    }

    std::sort(students.begin(), students.end(),
              [](const Student &a, const Student &b) {
                  return a.id < b.id;
              });

    std::ofstream out("received_students.csv");
    for (const auto &s : students) {
        out << s.id << "," << s.name << "," << s.age << "," << s.grade << "\n";
    }

    auto end = std::chrono::high_resolution_clock::now();

    std::cout << "Records processed: " << students.size() << "\n";
    std::cout << "Time taken (ms): "
              << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count()
              << "\n";

    return 0;
}
